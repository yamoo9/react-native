import React from 'react'
import { number, string } from 'prop-types'
import { View } from 'react-native'
import { Ionicons } from '@expo/vector-icons'

function _convertRatingToIntDecimal(rating) {
  const convertNumberToArray = rating.toFixed(1).split('.')
  const int = convertNumberToArray[0] * 1
  const decimal = `0.${convertNumberToArray[1]}` * 1
  return { int, decimal }
}

const RatingStars = ({ rating, size, color, count }) => {
  const stars = [...Array(Math.ceil(count))]
  const { int, decimal } = _convertRatingToIntDecimal(rating)
  return (
    <View style={{ flexDirection: 'row', marginTop: -7 }}>
      {stars.map(($, index) => {
        let name =
          int > index
            ? 'md-star'
            : decimal >= 0.5 && int === index
            ? 'md-star-half'
            : 'md-star-outline'
        return <Ionicons key={index} name={name} size={size} color={color} />
      })}
    </View>
  )
}

RatingStars.defaultProps = {
  size: 32,
  color: '#fde13e',
  count: 5,
}

RatingStars.propTypes = {
  rating: number.isRequired,
  size: number,
  color: string,
  count: number,
}

export default RatingStars
