/** ------------------------------------------------
 * ECMAScript 2015+
 * - ES6+ 문법을 사용해 API를 작성합니다.
 * ------------------------------------------------ */

/**
 * genreService 모듈에서 getGenreByName 멤버 추출
 */
// Node.js 모듈
// React Native <- Metro, Webpack
// resources
// const getGenreByName = require('./genreService').getGenreByName

// const mistery = getGenreByName('미스터리')

// console.log(mistery)

// ES 표준 모듈
import { getGenreByName } from './genreService'

/**
 * 무비(Movies)
 */
const movies = [
  {
    _id: "5b21ca3eeb7f6fbccd471815",
    title: "어벤져스: 엔드게임",
    subtitle: "Avengers: Endgame",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=136900",
    image:
      "https://movie-phinf.pstatic.net/20190417_250/1555465284425i6WQE_JPEG/movie_image.jpg",
    pubDate: "2019",
    genre: { _id: "5b21ca3eeb7f6fbccd471818", name: "액션" },
    numberInStock: 6,
    dailyRentalRate: 9.43
  },
  {
    _id: "5b21ca3eeb7f6fbccd471816",
    title: "뷰티플 마인드",
    subtitle: "Listen to Your Heart. The Beautiful Mind",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=177543",
    image:
      "https://movie-phinf.pstatic.net/20190401_109/1554082549248W2iyl_JPEG/movie_image.jpg",
    pubDate: "2019",
    genre: { _id: "5b21ca3eeb7f6fbccd471825", name: "다큐멘터리" },
    numberInStock: 5,
    dailyRentalRate: 9.83
  },
  {
    _id: "5b21ca3eeb7f6fbccd471817",
    title: "고양이 여행 리포트",
    subtitle: "旅猫リポート, The Travelling Cat Chronicles",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=174321",
    image:
      "https://movie-phinf.pstatic.net/20190419_4/15556641782554xyEQ_JPEG/movie_image.jpg",
    pubDate: "2019",
    genre: { _id: "5b21ca3eeb7f6fbccd471831", name: "드라마" },
    numberInStock: 8,
    dailyRentalRate: 9.06
  },
  {
    _id: "5b21ca3eeb7f6fbccd471819",
    title: "내부자들: 디 오리지널",
    subtitle: "Inside Men: The Original",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=147001",
    image:
      "https://movie-phinf.pstatic.net/20151231_70/14515598150769qgj2_JPEG/movie_image.jpg",
    pubDate: "2015",
    genre: { _id: "5b21ca3eeb7f6fbccd471831", name: "드라마" },
    numberInStock: 7,
    dailyRentalRate: 9.09
  },
  {
    _id: "5b21ca3eeb7f6fbccd47181a",
    title: "싱글라이더",
    subtitle: "A single rider",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=146459",
    image:
      "https://movie-phinf.pstatic.net/20170223_77/1487828550952mDECT_JPEG/movie_image.jpg",
    pubDate: "2017",
    genre: { _id: "5b21ca3eeb7f6fbccd471831", name: "드라마" },
    numberInStock: 4,
    dailyRentalRate: 8.01
  },
  {
    _id: "5b21ca3eeb7f6fbccd47181b",
    title: "그 해 여름",
    subtitle: "Once In A Summer",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=46985",
    image:
      "https://movie-phinf.pstatic.net/20111223_121/1324570748255LDMxf_JPEG/movie_image.jpg",
    pubDate: "2006",
    genre: { _id: "5b21ca3eeb7f6fbccd471814", name: "Comedy" },
    numberInStock: 1,
    dailyRentalRate: 8.79
  },
  {
    _id: "5b21ca3eeb7f6fbccd47181e",
    title: "태양은 가득히",
    subtitle: "Plein Soleil, Purple Noon",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=10514",
    image:
      "https://movie-phinf.pstatic.net/20111221_98/13244519127394BWFv_JPEG/movie_image.jpg",
    pubDate: "1960",
    genre: { _id: "5b21ca3eeb7f6fbccd471820", name: "Thriller" },
    numberInStock: 0,
    dailyRentalRate: 8.67
  },
  {
    _id: "5b21ca3eeb7f6fbccd47181f",
    title: "우리들",
    subtitle: "THE WORLD OF US",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=146504",
    image:
      "https://movie-phinf.pstatic.net/20160519_125/1463633078640zLLTy_JPEG/movie_image.jpg",
    pubDate: "2015",
    genre: { _id: "5b21ca3eeb7f6fbccd471831", name: "드라마" },
    numberInStock: 4,
    dailyRentalRate: 9.21
  },
  {
    _id: "5b21ca3eeb7f6fbccd471821",
    title: "다시, 봄",
    subtitle: "Spring, Again",
    link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=177511",
    image:
      "https://movie-phinf.pstatic.net/20190328_260/1553739672852J9R3l_JPEG/movie_image.jpg",
    pubDate: "2018",
    genre: { _id: "5b21ca3eeb7f6fbccd471831", name: "드라마" },
    numberInStock: 7,
    dailyRentalRate: 8.63
  }
];

/**
 * getMovies()
 * - 모든 무비 데이터(배열 복제) 반환
 */
export const getMovies = () => movies.slice()

/**
 * getMovieById(id)
 * - 전달 받은 id와 일치하는 무비 데이터(객체) 반환
 */
const getMovieById = id => getMovies().find(m => m._id === id)

/**
 * getMovieByTitle(title)
 * - 전달 받은 title과 일치하는 무비 데이터(객체) 반환
 */
export const getMovieByTitle = title => getMovies().find(m => m.title === title)


/**
 * saveMovie(movie)
 * - 전달된 무비 데이터(객체)를 무비 데이터베이스(배열)에 저장 후, 새로운 무비(객체) 반환
 * --------------------------------------------------------------------
 * 새로운 무비 객체 정보
 * - _id (없을 경우 Date.now() 이용)
 * - title
 * - subtitle
 * - link
 * - image
 * - pubDate
 * - genre(genreServie.getGenreByName 이용)
 * - numberInStock
 * - dailyRentalRate   
 */
const saveMovie = (movie) => {
  // 신규 무비(_id 속성이 없다), 기존 무비
  if (!movie) return null
  const movies = getMovies()
  const movieInDB = movies.find(m => m._id === movie._id) || {}
  
  // 사용자로부터 입력 받은 movies 객체의 key, value를 순환하여
  // movieInDB의 속성으로 할당한다.
  for (let [key, value] of Object.entries(movie)) {
    // 단, movie.genreName 속성의 경우는
    // getGenreByName 모듈을 사용해 모듈 객체를 movieInDB.genre로
    // 설정한다.
    if ( key === 'genreName' ) {
      movieInDB.genre = getGenreByName(value)
      continue
    }
    movieInDB[key] = value
  }
  // movieInDB의 _id 속성이 없는 경우
  if (!movieInDB._id) {
    // _id 값을 고유한 식별자를 추가
    // Date.now().toString()
    movieInDB._id = `5b21ca3eeb7${Date.now().toString()}`
    // 신규 무비 -> 기존 무비 push
    movies.push(movieInDB)
  }
  // movieInDB의 _id 속성이 있는 경우
  else {
    // 기존 무비 아이템을 찾아 사용자가 전달한 정보 값으로 업데이트
    // Array.prototype.findIndex
    const idx = movies.findIndex(m => m._id === movieInDB._id)
    // Array.prototype.splice(startIndex, ?deleteCount, ...addedItem)
    movies.splice(idx, 1, movieInDB)
  }
  // 사용자가 입력한 정보를 토대로 만들어진 무비 객체를 반환
  return movieInDB
}

const savedMovie = saveMovie({
  title: "검찰측의 죄인",
  subtitle: "検察側の罪人, Kensatsu gawa no zainin",
  link: "https://movie.naver.com/movie/bi/mi/basic.nhn?code=164103",
  image: "https://movie-phinf.pstatic.net/20190214_183/1550124128940CthGD_JPEG/movie_image.jpg",
  pubDate: "2018",
  genreName: "미스터리",
  numberInStock: 2,
  dailyRentalRate: 8.7
})

// console.log('delete before:', movies.length)

/**
 * deleteMovie(id)
 * - 전달 받은 id와 일치하는 무비 데이터(객체) 삭제 후, 삭제된 무비(객체) 반환
 */
const deleteMovie = id => {
  const _movies = getMovies()
  const idx = _movies.findIndex(m => m._id === id)
  movies.splice(idx, 1) // 제거
  return _movies.find(m => m._id === id) // 찾아서 반환
}

// deleteMovie('5b21ca3eeb7f6fbccd471821')

// console.log('delete after:', movies.length)