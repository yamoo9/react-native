/** ------------------------------------------------
 * ECMAScript 2015+
 * - ES6+ 문법을 사용해 API를 작성합니다.
 * ------------------------------------------------ */

/**
 * 장르(Genres)
 */
const genres = [
  { _id: "5b21ca3eeb7f6fbccd471818", name: "액션" },
  { _id: "5b21ca3eeb7f6fbccd471814", name: "코미디" },
  { _id: "5b21ca3eeb7f6fbccd471820", name: "스릴러" },
  { _id: "5b21ca3eeb7f6fbccd471825", name: "다큐멘터리" },
  { _id: "5b21ca3eeb7f6fbccd471831", name: "드라마" },
  { _id: "5b21ca3eeb7f6fbccd471844", name: "미스터리" },
];

/**
 * getGenres()
 * - 모든 장르 데이터(배열)를 반환
 */
const getGenres = () => [...genres]
// const getGenres = () => genres.slice()

/**
 * getGenreByName(name)
 * - 전달된 name과 일치하는 장르(객체) 반환
 */
export const getGenreByName = name => 
  getGenres().find((g, i) => g.name === name)

/**
 * getGenreById(id)
 * - 전달된 id와 일치하는 장르(객체) 반환
 */
const getGenreById = id =>
  getGenres().find(g => g._id === id)


// Node.js 모듈 내보내기
// exports
// module.exports

// module.exports = {
//   getGenreByName,
//   getGenreById
// }

// ES 표준 모듈
// export default {
//   getGenreByName
// }