// 모듈 관리 -> 번들링 도구 -> 프론트엔드 반영
import { getMovies, getMovieByTitle } from './services/movieService'

// React 프로그래밍
// class 문법

const { createElement, Component } = React // React 요소 생성

// UI 
class AppHeader extends Component {
    render() {
        // UI 요소 렌더링
        // <h1>Hello React!</h1>
        return createElement(
            'h1',
            null,
            'Hello React!'
        )
    }
}

ReactDOM.render(
    // React 요소,
    // <AppHeader/>,
    createElement(AppHeader),
    // DOM의 어떤 요소
    document.getElementById('root')
)