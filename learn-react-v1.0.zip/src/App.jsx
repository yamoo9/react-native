import React from 'react'
import './styles/App.css'

// 스타일 모듈
// React Native에서 처리하는 방식 모방
import { getStyle } from './styles/styleModule'

// React 컴포넌트(클래스 또는 함수형)
import Figure from './components/Figure'
import Movies from './components/Movies'

// App 컴포넌트
const App = () => (
  // 부모 컴포넌트
  <div style={getStyle('app')}>
    {/* 자식(하위) 컴포넌트 */}
    <Figure />
    <Movies />
  </div>
)

export default App
