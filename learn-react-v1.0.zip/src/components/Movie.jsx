import React from 'react'
import MoviePosterLink from './MoviePosterLink'

// Movie 컴포넌트
// 상태(state), 라이프 사이클을 설정하려면 '클래스 컴포넌트' 사용
class Movie extends React.Component {
  // 라이프 사이클: constrcutor
  // 컴포넌트 생성 시점에 실행 됨
  constructor(props) {
    // props 매개변수는 부모 컴포넌트가 전달한 속성 집합
    // constructor() 사용 시, super() 반드시 실행되어야 함
    super(props)

    // 컴포넌트 상태(state) 정의
    this.state = {
      index: props.idx + 1,
      prefix: '무비 정보: ',
    }
  }

  // 클래스 메서드 설정 시 static 접근 제어자 설정
  static getIndex(index) {
    return index < 10 ? `0${index}` : index
  }

  render() {
    // 컴포넌트의 props, state 속성 구조 분해 할당
    const {
      movie: { _id, title, subtitle, pubDate, link, image },
    } = this.props
    const { index } = this.state

    return (
      <li>
        {/* 콘텐츠 바인딩(또는 컴파일) */}
        <h2>{`${Movie.getIndex(index)} ${title}`}</h2>
        <div className="subtitle-pubdate">
          <span className="subtitme">{subtitle}</span>&nbsp;
          <time className="pubDate">{pubDate}</time>
        </div>
        {/* 자식 컴포넌트에 속성 전달 */}
        <MoviePosterLink
          // 속성 바인딩(또는 컴파일)
          id={_id}
          link={link}
          title={title}
          image={image}
        />
      </li>
    )
  }
}

export default Movie
