import React from 'react'

// 무비 정보 데이터 패치(동기)
import { getMovies } from '../services/movieService'

// 자식 컴포넌트 불러오기
import Movie from './Movie'

// 무비 정보 설정(동기)
const movies = getMovies()

// Movies 컴포넌트(부모)
// 상태(state), 라이프 사이클을 설정하려면 '클래스 컴포넌트' 사용
class Movies extends React.Component {
  // 컴포넌트 마운트 이후 시점에서 콜백
  componentDidMount() {
    // 네트워킹을 통해 '데이터 패치' 실행(비동기)
    this.fetchData()
  }

  fetchData() {
    // Fetch API
    // 서버와 비동기 통신
    // 서버에 데이터 요청
    // 서버에서 데이터 패치
    // 상태 업데이트
    // UI 업데이트
    fetch('https://api.myjson.com/bins/ljbf7')
      // Promise 객체 받음
      // 응답에서 전달된 데이터(스트림) → json() 메서드로 JSON 변경 반환
      .then(response => response.json())
      // 전달된 JSON에서 data 속성을 반환
      .then(json => json.data)
      // 전달된 data를 Console 패널에 출력
      .then(data => console.log(data))
      // 네트워크 오류 발생 시, 오류 메시지 출력
      .catch(error => console.error(error.message))
  }

  // 클래스 컴포넌트는 render() 메서드를 통해
  // UI를 업데이트 함
  render() {
    // JSX 또는 React 요소(element)를 반환
    return (
      <ul className="movie-container">
        {/* JSX 내에서 {}를 사용해 JavaScript 식을 사용 */}
        {/* Array.prototype.map을 활용한 리스트 렌더링 */}
        {movies.map((movie, index) => (
          // Movie 자식 컴포넌트에 속성(props) 전달
          <Movie
            // 리스트 렌더링 시에 key 설정 필수!
            key={movie._id}
            // movie 객체 전달
            movie={movie}
            // 리스트 인덱스 전달
            idx={index}
          />
        ))}
      </ul>
    )
  }
}

export default Movies
