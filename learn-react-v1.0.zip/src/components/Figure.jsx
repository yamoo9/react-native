import React from 'react'
import { getStyle } from '../styles/styleModule'

// 컴포넌트 상태가 아니므로
// state 객체의 속성을 변경해도
// UI는 업데이트 되지 않음
const state = {
  image: {
    src: require('../assets/logo.svg'),
    aniClass: 'app-logo',
    alt: 'React 로고',
  },
}

// const { image } = state
// const { src, alt, aniClass, assignAnimation } = image

// 위와 같은 '구조 분해 할당' 구문을 아래와 같이 사용 가능
// ⬇︎

const {
  image: { src, alt, aniClass, assignAnimation },
} = state

export default function Figure() {
  return (
    // 속성 바인딩(또는 컴파일)
    <figure style={getStyle('figure')}>
      {/* JSX 안에서의 주석 처리 */}
      <img
        // JSX 태그 안에서의 주석 처리
        className={aniClass}
        src={src}
        alt={alt}
      />
    </figure>
  )
}
