import React from 'react'

// MvoiePosterLink 컴포넌트
// 함수형 컴포넌트는 상태(state), 라이프 사이클(life cycle)을 가지지 못함
// ※ 단, React Hooks을 사용하면 함수형 컴포넌트도 상태 설정이 가능하지만,
//   React Native는 현재(2019.05) Hooks을 지원하지 않음
const MoviePosterLink = ({ id, title, link, image }) => (
  // return 없이 JSX를 바로 반환할 경우: () => (<div>...</div>)
  <a
    href={link}
    // JSX에 설정하는 일반적인 속성은 camelCase로 설정
    className="movie-poster-link"
    // 단, WAI-ARIA 접근성 속성(aria-*) 설정 시에는 camelCase가 아님
    aria-describedby={id}
    // ES6 템플릿 리터럴 사용 예
    title={`클릭하면 ${title} 영화 페이지'로 이동합니다.`}>
    <img
      // 이미지 대체 텍스트는 중복되는 콘텐츠가 있을 경우,
      // 또는 문맥(context) 상 제공하지 않아도 될 경우
      // 값을 비워두면 스크린 리더가 읽지 않음
      alt=""
      src={image}
      // 인라인 스타일 설정도 가능
      // 단, 많이 사용하면 코드 가독성이 현저히 떨어짐
      style={{ width: 120, height: 'auto' }}
    />
    {/*
      sr-only 클래스 속성에 설정된 스타일은 화면에 보이진 않지만,
      스크린 리더 사용자에게 정보를 제공
     */}
    <p
      className="sr-only"
      // aria-describedby 속성과 연결 됨
      // 연결된 콘텐츠를 설명
      id={id}>
      클릭하면 '{title} 영화 페이지'로 이동합니다.
    </p>
  </a>
)

export default MoviePosterLink
