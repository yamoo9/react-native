import React, { Component } from 'react'
import './styles/App.css'

// 스타일 모듈
// React Native에서 처리하는 방식 모방
import { getStyle } from './styles/styleModule'

// React 컴포넌트(클래스 또는 함수형)
import Figure from './components/Figure'
import Movies from './components/Movies'
import AppSearchInput from './components/common/AppSearchInput'

// App 컴포넌트
class App extends Component {
  state = {
    image: {
      src: require('./assets/logo.svg'),
      aniClass: 'app-logo',
      alt: 'React 로고',
    },
    movies: [],
    keyword: '',
  }

  // 컴포넌트 마운트 이후 시점에서 콜백
  componentDidMount() {
    // 네트워킹을 통해 '데이터 패치' 실행(비동기)
    this.fetchData()
  }

  fetchData() {
    // Fetch API -> React Native
    // 서버와 비동기 통신
    // 서버에 데이터 요청
    // 서버에서 데이터 패치
    // 상태 업데이트
    // UI 업데이트
    // GET, POST, PUT, DELETE
    fetch('https://api.myjson.com/bins/6ju7b')
      // Promise 객체 받음
      // 응답에서 전달된 데이터(스트림) → json() 메서드로 JSON 변경 반환
      .then(response => response.json())
      // 전달된 JSON에서 data 속성을 반환
      .then(json => json.data)
      // 전달된 data를 Console 패널에 출력
      .then(data => {
        // 컴포넌트 상태 업데이트
        // console.log(data) // [{}, {}, ...]
        // 아래 방법은 React에서 사용하면 안됩니다.
        // this.state.movies = this.state.movies.concat(data)
        // React는 상태 데이터 업데이를 위해 컴포넌트의 setState() 메서드 사용
        // this.setState({
        //   movies: data,
        // })

        this.setState(prevState => ({
          movies: [...prevState.movies, ...data],
        }))
      })
      // 네트워크 오류 발생 시, 오류 메시지 출력
      .catch(error => console.error(error.message))
  }

  handleSearch = userSearchKeyword => {
    this.setState({
      keyword: userSearchKeyword,
    })
  }

  render() {
    const { image, keyword, movies } = this.state
    return (
      // 부모 컴포넌트
      <div style={getStyle('app')}>
        {/* 자식(하위) 컴포넌트 */}
        <Figure image={image} />
        <AppSearchInput
          connectId="search-movie"
          label="영화 검색"
          value={keyword}
          placeholder="영화 이름을 입력하세요."
          onSearch={this.handleSearch}
        />
        <Movies search={keyword} movies={movies} />
      </div>
    )
  }
}

export default App
