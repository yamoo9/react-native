import {
  INCREMENT_COUNT,
  DECREMENT_COUNT,
  RESET_COUNT
} from '../actions/actionTypes'

// 상태(state)
const initState = {
  count: 0,
}

// 리듀서(함수)
// (state, action)
const reducer = (state = initState, action) => {
  // action => { type: INCREMENT_COUNT, payload: 업데이트 데이터 }
  switch (action.type) {
    case INCREMENT_COUNT:
      // 상태 업데이트
      return { ...state, count: state.count + 1 }
    case DECREMENT_COUNT:
      // 상태 업데이트
      return { ...state, count: state.count - 1 }
    case RESET_COUNT:
      return { ...state, count: action.payload }
    default:
      return state
  }
}

export default reducer
