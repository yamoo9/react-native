import { createStore } from 'redux'

// 리듀서(함수) 불러오기
import reducer from './reducers/counter'

// 스토어 생성
const store = createStore(
  reducer,
  window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
)

export default store
