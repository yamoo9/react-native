// 액션(actions)
// 액션 타입
// 상수
export const INCREMENT_COUNT = '카운트 증가'
export const DECREMENT_COUNT = '카운트 감소'
export const RESET_COUNT = '카운트 초기화'
