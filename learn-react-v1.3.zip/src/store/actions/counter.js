import {
  INCREMENT_COUNT,
  DECREMENT_COUNT,
  RESET_COUNT
} from '../actions/actionTypes'

// 액션 생성 함수
export const increaseCountAction = () => {
  return { type: INCREMENT_COUNT }
}
export const decreaseCountAction = () => {
  return { type: DECREMENT_COUNT }
}
export const resetCountAction = (initCount) => {
  return { type: RESET_COUNT, payload: initCount }
}