// React, ReactDOM 모듈 불러오기
import React from 'react'
import ReactDOM from 'react-dom'

// CSS 스타일 불러오기
import './styles/index.css'

// React 컴포넌트(클래스 또는 함수형)
import App from './App'

// 실제 DOM에 가상 DOM 노드 마운팅(결합)
ReactDOM.render(
  // React 요소(인스턴스)
  // 가상 DOM 노드: VNode
  <App />,
  // 실제 DOM 노드
  document.getElementById('root')
)
