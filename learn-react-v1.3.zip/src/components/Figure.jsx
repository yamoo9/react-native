import React from 'react'
import { getStyle } from '../styles/styleModule'

const Figure = ({ image }) => {
  const { aniClass, src, alt } = image
  return (
    // 속성 바인딩(또는 컴파일)
    <figure style={getStyle('figure')}>
      {/* JSX 안에서의 주석 처리 */}
      <img
        // JSX 태그 안에서의 주석 처리
        className={aniClass}
        src={src}
        alt={alt}
      />
    </figure>
  )
}

export default Figure
