import React, { Component } from 'react'

// 무비 정보 데이터 패치(동기)
// import { getMovies } from '../services/movieService'

// 자식 컴포넌트 불러오기
import Movie from './Movie'

// 무비 정보 설정(동기)
// const movies = getMovies()

// Movies 컴포넌트(부모)
// 상태(state), 라이프 사이클을 설정하려면 '클래스 컴포넌트' 사용
class Movies extends Component {
  // 클래스 컴포넌트는 render() 메서드를 통해
  // UI를 업데이트 함
  render() {
    // JSX 또는 React 요소(element)를 반환
    const { search, movies } = this.props
    const searchedMovies = movies.filter(movie =>
      search.trim() === '' ? movie : movie.title.includes(search)
    )
    return (
      <ul className="movie-container">
        {/* JSX 내에서 {}를 사용해 JavaScript 식을 사용 */}
        {/* Array.prototype.map을 활용한 리스트 렌더링 */}
        {searchedMovies.map((movie, index) => (
          // Movie 자식 컴포넌트에 속성(props) 전달
          <Movie
            // 리스트 렌더링 시에 key 설정 필수!
            key={movie._id}
            // movie 객체 전달
            movie={movie}
            // 리스트 인덱스 전달
            idx={index}
          />
        ))}
      </ul>
    )
  }
}

export default Movies
