import React, { Component } from 'react'
import './styles/App.css'

// 스타일 모듈
// React Native에서 처리하는 방식 모방
import { getStyle } from './styles/styleModule'

// React 컴포넌트(클래스 또는 함수형)
import Figure from './components/Figure'
import Movies from './components/Movies'

// App 컴포넌트
class App extends Component {
  state = {
    image: {
      src: require('./assets/logo.svg'),
      aniClass: 'app-logo',
      alt: 'React 로고',
    },
  }
  render() {
    return (
      // 부모 컴포넌트
      <div style={getStyle('app')}>
        {/* 자식(하위) 컴포넌트 */}
        <Figure image={this.state.image} />
        <Movies />
      </div>
    )
  }
}

export default App
