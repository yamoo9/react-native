// React Native 스타일 모방
// 개별 내보내기
export const styles = {
  app: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'center',
    minHeight: '100vh',
    backgroundColor: '#162442',
    color: '#fff',
  },
  figure: {
    margin: '30px 0 0',
  },
  img: {
    verticalAlign: 'middle',
    width: '300px',
    height: 'auto',
  },
}
// 개별 내보내기
export const getStyle = key => styles[key]

// 기본 객체로 내보내기
export default {
  styles,
  getStyle,
}
