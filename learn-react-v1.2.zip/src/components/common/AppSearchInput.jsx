import React from 'react'
import { string, func } from 'prop-types'
import styled from 'styled-components'

const StyledAppSearchInput = styled.div`
  padding: 1rem;

  input {
    border: 3px solid #61dafb;
    border-radius: 6px;
    padding: 0.65em 1.2em;
    background: #152342;
    color: #fff;
    font-size: 1rem;
    transition: all 0.4s ease-out;

    :hover,
    :focus {
      border-color: #fff;
    }
    :focus {
      outline: none;
    }
    ::placeholder {
      color: #61dafb;
    }
  }

  button {
    cursor: pointer;
    position: relative;
    top: -1px;
    margin-left: 10px;
    border: 3px solid transparent;
    border-radius: 6px;
    padding: 0.6em 1em;
    background: #61dafb;
    font-weight: bold;
    font-size: 1rem;
    color: #222837;
    transition: all 0.2s ease;

    :hover {
      border-color: #45598e;
      background: transparent;
      color: #fff;
    }
  }
`

const AppSearchInput = ({ connectId, label, placeholder, value, buttonName, onSearch }) => (
  <StyledAppSearchInput>
    <label className="sr-only" htmlFor={connectId}>
      {label}
    </label>
    <input
      type="search"
      id={connectId}
      placeholder={placeholder}
      value={value}
      onChange={e => onSearch(e.target.value)}
    />
    <button type="button">{buttonName}</button>
  </StyledAppSearchInput>
)

AppSearchInput.propTypes = {
  connectId: string.isRequired,
  label: string.isRequired,
  value: string.isRequired,
  onSearch: func,
  buttonName: string,
  placeholder: string,
}
AppSearchInput.defaultProps = {
  placeholder: '검색어를 입력하세요.',
  buttonName: '검색',
  onSearch: () => {},
}

export default AppSearchInput
